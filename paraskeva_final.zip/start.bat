@echo off
echo ============================================
echo    PARASKEVA.AI v4 - Starting...
echo ============================================
start "" "%~dp0paraskeva_v4.html"
echo Opened in browser!
timeout /t 3
