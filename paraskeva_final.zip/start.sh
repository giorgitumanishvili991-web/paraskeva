#!/bin/bash
echo "============================================"
echo "   PARASKEVA.AI v4 - Starting..."
echo "============================================"
DIR="$(cd "$(dirname "$0")" && pwd)"
FILE="$DIR/paraskeva_v4.html"

if command -v xdg-open &>/dev/null; then
  xdg-open "$FILE"
elif command -v open &>/dev/null; then
  open "$FILE"
else
  echo "Browser ვერ გაიხსნა. გახსენი ხელით: $FILE"
fi

echo "Opened in browser!"
